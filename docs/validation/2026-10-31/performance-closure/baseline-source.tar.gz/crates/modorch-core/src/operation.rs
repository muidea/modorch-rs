use crate::*;
#[cfg(test)]
use loom::sync::Mutex;
#[cfg(not(test))]
use std::sync::Mutex;
use std::{
    collections::{BTreeSet, HashMap},
    future::Future,
    sync::{Arc, Weak},
};
use tokio::sync::Notify;

#[derive(Clone, Copy, PartialEq)]
enum Admission {
    Startup,
    Open,
    Closed,
    Terminated,
}
struct State {
    admission: Admission,
    next: u64,
    blocked: BTreeSet<ComponentRef>,
    generations: HashMap<ComponentRef, u64>,
    privileged: BTreeSet<OperationId>,
    active: HashMap<OperationId, ComponentRef>,
}
static NEXT_APPLICATION: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
struct Inner {
    application_id: ApplicationId,
    state: Mutex<State>,
    changed: Notify,
}
#[derive(Clone)]
pub struct OperationTracker(Arc<Inner>);
struct LeaseInner {
    tracker: Weak<Inner>,
    id: OperationId,
}
/// Clones share a single counted operation; the last clone releases it.
#[derive(Clone)]
pub struct OperationLease(Arc<LeaseInner>);
tokio::task_local! { static CURRENT: Option<OperationLease>; }
impl Default for OperationTracker {
    fn default() -> Self {
        Self::new()
    }
}
impl OperationTracker {
    pub fn new() -> Self {
        Self(Arc::new(Inner {
            application_id: NEXT_APPLICATION.fetch_add(1, std::sync::atomic::Ordering::Relaxed),
            state: Mutex::new(State {
                admission: Admission::Startup,
                next: 1,
                blocked: BTreeSet::new(),
                generations: HashMap::new(),
                privileged: BTreeSet::new(),
                active: HashMap::new(),
            }),
            changed: Notify::new(),
        }))
    }
    pub fn application_id(&self) -> ApplicationId {
        self.0.application_id
    }
    pub fn open(&self) -> FrameworkResult<()> {
        let mut state = self.0.state.lock().unwrap();
        if state.admission != Admission::Startup {
            return Err(FrameworkError::Closed);
        }
        state.admission = Admission::Open;
        Ok(())
    }
    pub fn close(&self) {
        let mut state = self.0.state.lock().unwrap();
        if state.admission != Admission::Terminated {
            state.admission = Admission::Closed;
        }
        self.0.changed.notify_waiters();
    }
    /// Reserve the lifecycle coordinator's final causal chain and close roots in
    /// one linearized step. Only the runtime coordinator uses this capability.
    #[doc(hidden)]
    pub fn close_with_lease(&self, owner: ComponentRef) -> Option<OperationLease> {
        let mut state = self.0.state.lock().unwrap();
        if matches!(state.admission, Admission::Closed | Admission::Terminated) {
            return None;
        }
        state.admission = Admission::Closed;
        let id = state.next;
        state.privileged.insert(id);
        state.next += 1;
        state.active.insert(id, owner);
        Some(OperationLease(Arc::new(LeaseInner {
            tracker: Arc::downgrade(&self.0),
            id,
        })))
    }
    pub fn terminate(&self) {
        self.0.state.lock().unwrap().admission = Admission::Terminated;
        self.0.changed.notify_waiters();
    }
    pub fn is_closed(&self) -> bool {
        matches!(
            self.0.state.lock().unwrap().admission,
            Admission::Closed | Admission::Terminated
        )
    }
    pub fn current(&self) -> Option<OperationLease> {
        CURRENT
            .try_with(Clone::clone)
            .ok()
            .flatten()
            .filter(|lease| Weak::ptr_eq(&lease.0.tracker, &Arc::downgrade(&self.0)))
    }
    pub fn admit(&self, owner: ComponentRef) -> FrameworkResult<OperationLease> {
        self.admit_inner(owner, false, None)
    }
    /// Framework startup tasks/services may run before external ingress opens.
    pub fn admit_background(&self, owner: ComponentRef) -> FrameworkResult<OperationLease> {
        self.admit_inner(owner, true, None)
    }
    fn admit_inner(
        &self,
        owner: ComponentRef,
        startup: bool,
        generation: Option<u64>,
    ) -> FrameworkResult<OperationLease> {
        let parent = self.current();
        let mut state = self.0.state.lock().unwrap();
        if generation
            .is_some_and(|expected| *state.generations.get(&owner).unwrap_or(&0) != expected)
        {
            return Err(FrameworkError::Closed);
        }
        let child = parent
            .as_ref()
            .is_some_and(|p| state.active.contains_key(&p.id()));
        match state.admission {
            Admission::Terminated => return Err(FrameworkError::Closed),
            Admission::Closed if !child => return Err(FrameworkError::Closed),
            Admission::Startup if !startup => return Err(FrameworkError::NotReady),
            _ => {}
        }
        if state.blocked.contains(&owner)
            && !parent.as_ref().is_some_and(|p| {
                state.privileged.contains(&p.id())
                    || state
                        .active
                        .get(&p.id())
                        .is_some_and(|c| state.blocked.contains(c))
            })
        {
            return Err(FrameworkError::Closed);
        }
        let id = state.next;
        state.next += 1;
        state.active.insert(id, owner);
        Ok(OperationLease(Arc::new(LeaseInner {
            tracker: Arc::downgrade(&self.0),
            id,
        })))
    }
    pub async fn scope<F: Future>(&self, lease: OperationLease, future: F) -> F::Output {
        {
            use tracing::Instrument;
            let span = tracing::info_span!(
                "operation",
                application_id = self.application_id(),
                operation_id = lease.id()
            );
            CURRENT.scope(Some(lease), future.instrument(span)).await
        }
    }
    /// Establish a fresh external root even inside an owner task.
    pub fn as_root<T>(&self, action: impl FnOnce() -> T) -> T {
        CURRENT.sync_scope(None, action)
    }
    pub fn admit_bound(
        &self,
        owner: ComponentRef,
        generation: u64,
    ) -> FrameworkResult<OperationLease> {
        self.admit_inner(owner, true, Some(generation))
    }
    pub fn generation(&self, owner: &ComponentRef) -> u64 {
        *self
            .0
            .state
            .lock()
            .unwrap()
            .generations
            .get(owner)
            .unwrap_or(&0)
    }
    pub fn generation_valid(&self, owner: &ComponentRef, generation: u64) -> bool {
        self.generation(owner) == generation
    }
    /// Close a dependency closure to outside producers and reserve its cleanup chain.
    pub fn close_owners(&self, owners: &BTreeSet<ComponentRef>) -> OperationLease {
        let mut state = self.0.state.lock().unwrap();
        state.blocked.extend(owners.iter().cloned());
        let id = state.next;
        state.next += 1;
        state
            .active
            .insert(id, owners.first().expect("nonempty closure").clone());
        self.0.changed.notify_waiters();
        OperationLease(Arc::new(LeaseInner {
            tracker: Arc::downgrade(&self.0),
            id,
        }))
    }
    /// Advance only after all old-generation work has drained. Gates stay closed
    /// until the replacement instances pass readiness.
    pub fn advance_owners(&self, owners: &BTreeSet<ComponentRef>) -> FrameworkResult<()> {
        let mut state = self.0.state.lock().unwrap();
        if owners
            .iter()
            .any(|c| state.active.values().any(|owner| owner == c))
        {
            return Err(FrameworkError::InvalidConfig(
                "old generation has pending operations".into(),
            ));
        }
        for owner in owners {
            *state.generations.entry(owner.clone()).or_default() += 1;
        }
        Ok(())
    }
    pub fn open_owners(&self, owners: &BTreeSet<ComponentRef>) -> FrameworkResult<()> {
        let mut state = self.0.state.lock().unwrap();
        if state.admission != Admission::Open {
            return Err(FrameworkError::Closed);
        }
        for owner in owners {
            state.blocked.remove(owner);
        }
        self.0.changed.notify_waiters();
        Ok(())
    }
    pub fn pending_owners(&self, owners: &BTreeSet<ComponentRef>) -> PendingWork {
        let mut pending = self.pending();
        pending.owners.retain(|owner, _| owners.contains(owner));
        pending.operations = pending.owners.values().sum();
        pending
    }
    pub async fn drain_owners(&self, owners: &BTreeSet<ComponentRef>) {
        loop {
            let notified = self.0.changed.notified();
            tokio::pin!(notified);
            notified.as_mut().enable();
            if self.pending_owners(owners).operations == 0 {
                return;
            }
            notified.await;
        }
    }
    pub async fn admission_changed(&self) {
        self.0.changed.notified().await;
    }
    pub async fn scope_root<F: Future>(&self, future: F) -> F::Output {
        CURRENT.scope(None, future).await
    }
    pub fn pending(&self) -> PendingWork {
        let state = self.0.state.lock().unwrap();
        let mut owners = BTreeMap::new();
        for owner in state.active.values() {
            *owners.entry(owner.clone()).or_insert(0) += 1;
        }
        PendingWork {
            operations: state.active.len(),
            owners,
        }
    }
    /// After close, zero is a fixed point: no live parent remains to admit children.
    pub async fn drain(&self) {
        loop {
            let notified = self.0.changed.notified();
            tokio::pin!(notified);
            notified.as_mut().enable();
            if self.pending().operations == 0 {
                return;
            }
            notified.await;
        }
    }
}
impl OperationLease {
    pub fn id(&self) -> OperationId {
        self.0.id
    }
}
impl Drop for LeaseInner {
    fn drop(&mut self) {
        if let Some(tracker) = self.tracker.upgrade() {
            {
                let mut state = tracker.state.lock().unwrap();
                state.active.remove(&self.id);
                state.privileged.remove(&self.id);
            }
            tracker.changed.notify_waiters();
        }
    }
}

#[cfg(test)]
mod model {
    use super::*;
    #[test]
    fn close_and_admit_are_linearized_and_never_lose_leases() {
        loom::model(|| {
            let tracker = OperationTracker::new();
            tracker.open().unwrap();
            let producer = tracker.clone();
            let closer = tracker.clone();
            let submit =
                loom::thread::spawn(move || producer.admit(ComponentRef::module("worker")));
            let close = loom::thread::spawn(move || closer.close());
            let lease = submit.join().unwrap();
            close.join().unwrap();
            match lease {
                Ok(lease) => {
                    assert_eq!(tracker.pending().operations, 1);
                    drop(lease);
                }
                Err(FrameworkError::Closed) => assert_eq!(tracker.pending().operations, 0),
                Err(error) => panic!("{error}"),
            }
            assert_eq!(tracker.pending().operations, 0);
            assert!(tracker.admit(ComponentRef::module("late")).is_err());
        });
    }
    #[test]
    fn owner_generation_cannot_advance_while_an_old_task_is_admitted() {
        loom::model(|| {
            let tracker = OperationTracker::new();
            tracker.open().unwrap();
            let owner = ComponentRef::module("worker");
            let owners = BTreeSet::from([owner.clone()]);
            let worker = tracker.clone();
            let worker_owner = owner.clone();
            let submit = loom::thread::spawn(move || worker.admit_bound(worker_owner, 0));
            let cleanup = tracker.close_owners(&owners);
            drop(cleanup);
            let lease = submit.join().unwrap();
            if let Ok(lease) = lease {
                assert!(tracker.advance_owners(&owners).is_err());
                drop(lease);
            }
            tracker.advance_owners(&owners).unwrap();
            tracker.open_owners(&owners).unwrap();
            assert!(tracker.admit_bound(owner.clone(), 0).is_err());
            drop(tracker.admit_bound(owner, 1).unwrap());
            assert_eq!(tracker.pending().operations, 0);
        });
    }
}
