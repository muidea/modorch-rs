use modorch_core::*;
use modorch_scheduler::*;
use std::{
    sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    },
    time::Duration,
};
fn scheduler(
    tasks: usize,
    timers: usize,
) -> (
    TaskScheduler,
    SchedulerRuntime,
    OperationTracker,
    FailureReporter,
) {
    let tracker = OperationTracker::new();
    tracker.open().unwrap();
    let failures = FailureReporter::new();
    let runtime = SchedulerRuntime::new(tracker.clone(), failures.clone(), tasks, timers).unwrap();
    (
        runtime.for_owner(ComponentRef::module("worker")),
        runtime,
        tracker,
        failures,
    )
}
#[tokio::test]
async fn tasks_have_results_bounds_and_cooperative_shutdown() {
    let (scheduler, runtime, tracker, _) = scheduler(1, 1);
    let handle = scheduler
        .spawn(|cancel| async move {
            cancel.cancelled().await;
            tokio::time::sleep(Duration::from_millis(5)).await;
            Ok(())
        })
        .unwrap();
    assert!(matches!(
        scheduler.spawn(|_| async { Ok(()) }),
        Err(FrameworkError::Backpressure(_))
    ));
    tracker.close();
    runtime.begin_shutdown();
    assert_eq!(tracker.pending().operations, 1);
    handle.wait().await.unwrap();
    tracker.drain().await;
    assert_eq!(handle.state(), TaskState::Completed);
    assert!(matches!(
        scheduler.spawn(|_| async { Ok(()) }),
        Err(FrameworkError::Closed)
    ));
}
#[tokio::test]
async fn task_panic_is_failure_and_never_success() {
    let (scheduler, _, tracker, failures) = scheduler(4, 1);
    let handle = scheduler
        .spawn(|_| async {
            panic!("injected fault");
            #[allow(unreachable_code)]
            Ok(())
        })
        .unwrap();
    assert!(matches!(
        handle.wait().await,
        Err(FrameworkError::ExecutionFailed { .. })
    ));
    assert_eq!(handle.state(), TaskState::Failed);
    assert!(failures.current().is_some());
    tracker.close();
    tracker.drain().await;
}
#[tokio::test(start_paused = true)]
async fn timers_do_not_consume_task_slots_and_skip_overlapping_ticks() {
    let (scheduler, runtime, tracker, _) = scheduler(1, 1);
    let count = Arc::new(AtomicUsize::new(0));
    let task_count = count.clone();
    let timer = scheduler
        .interval(
            IntervalSpec {
                period: Duration::from_secs(1),
                policy: TickPolicy::SkipIfRunning,
            },
            Arc::new(move |cancel| {
                let count = task_count.clone();
                Box::pin(async move {
                    count.fetch_add(1, Ordering::SeqCst);
                    cancel.cancelled().await;
                    Ok(())
                })
            }),
        )
        .unwrap();
    assert!(matches!(
        scheduler.delay(
            Duration::from_secs(1),
            Arc::new(|_| Box::pin(async { Ok(()) }))
        ),
        Err(FrameworkError::Backpressure(_))
    ));
    tokio::task::yield_now().await;
    tokio::time::advance(Duration::from_secs(1)).await;
    tokio::task::yield_now().await;
    tokio::task::yield_now().await;
    assert_eq!(count.load(Ordering::SeqCst), 1);
    tokio::time::advance(Duration::from_secs(10)).await;
    tokio::task::yield_now().await;
    assert_eq!(count.load(Ordering::SeqCst), 1);
    tracker.close();
    runtime.begin_shutdown();
    timer.wait().await;
    tracker.drain().await;
    assert_eq!(tracker.pending().operations, 0);
}

#[tokio::test]
async fn forced_task_abort_has_a_cancelled_receipt_and_releases_its_owner() {
    let (scheduler, runtime, tracker, _) = scheduler(1, 1);
    let handle = scheduler
        .spawn(|_| async {
            std::future::pending::<()>().await;
            Ok(())
        })
        .unwrap();
    tokio::task::yield_now().await;
    runtime.force_cancel();
    assert!(matches!(
        handle.wait().await,
        Err(FrameworkError::Cancelled)
    ));
    assert_eq!(handle.state(), TaskState::Cancelled);
    tracker.close();
    tracker.drain().await;
    assert!(runtime.pending_owners().is_empty());
}
#[tokio::test(start_paused = true)]
async fn bounded_timer_queue_preserves_only_its_configured_backlog() {
    let (scheduler, runtime, tracker, _) = scheduler(8, 1);
    let gate = Arc::new(tokio::sync::Semaphore::new(0));
    let count = Arc::new(AtomicUsize::new(0));
    let task_gate = gate.clone();
    let task_count = count.clone();
    let timer = scheduler
        .interval(
            IntervalSpec {
                period: Duration::from_secs(1),
                policy: TickPolicy::QueueBounded { capacity: 2 },
            },
            Arc::new(move |_| {
                let gate = task_gate.clone();
                let count = task_count.clone();
                Box::pin(async move {
                    count.fetch_add(1, Ordering::SeqCst);
                    gate.acquire().await.unwrap().forget();
                    Ok(())
                })
            }),
        )
        .unwrap();
    tokio::task::yield_now().await;
    for _ in 0..5 {
        tokio::time::advance(Duration::from_secs(1)).await;
        for _ in 0..4 {
            tokio::task::yield_now().await;
        }
    }
    assert_eq!(count.load(Ordering::SeqCst), 1);
    gate.add_permits(3);
    for _ in 0..20 {
        tokio::task::yield_now().await;
    }
    assert_eq!(count.load(Ordering::SeqCst), 3);
    timer.cancel();
    timer.wait().await;
    tracker.close();
    runtime.begin_shutdown();
    tracker.drain().await;
}
#[tokio::test(start_paused = true)]
async fn timer_overlap_has_an_explicit_limit() {
    let (scheduler, runtime, tracker, _) = scheduler(8, 1);
    let count = Arc::new(AtomicUsize::new(0));
    let task_count = count.clone();
    let timer = scheduler
        .interval(
            IntervalSpec {
                period: Duration::from_secs(1),
                policy: TickPolicy::AllowOverlap { max_in_flight: 2 },
            },
            Arc::new(move |cancel| {
                let count = task_count.clone();
                Box::pin(async move {
                    count.fetch_add(1, Ordering::SeqCst);
                    cancel.cancelled().await;
                    Ok(())
                })
            }),
        )
        .unwrap();
    tokio::task::yield_now().await;
    for _ in 0..4 {
        tokio::time::advance(Duration::from_secs(1)).await;
        for _ in 0..4 {
            tokio::task::yield_now().await;
        }
    }
    assert_eq!(count.load(Ordering::SeqCst), 2);
    tracker.close();
    runtime.begin_shutdown();
    timer.wait().await;
    tracker.drain().await;
}

#[tokio::test]
async fn task_errors_retain_operation_owner_phase_and_retryability() {
    let (scheduler, _, tracker, failures) = scheduler(1, 1);
    let task = scheduler
        .spawn(|_| async {
            Err(FrameworkError::Backpressure(ComponentRef::module(
                "dependency",
            )))
        })
        .unwrap();
    let error = task.wait().await.unwrap_err();
    assert_eq!(error.operation_id(), Some(task.operation_id()));
    assert_eq!(error.component(), Some(&ComponentRef::module("worker")));
    assert_eq!(error.phase(), Some(Phase::Task));
    assert!(error.retryable());
    assert!(matches!(
        error.root_cause(),
        FrameworkError::Backpressure(_)
    ));
    assert_eq!(
        failures.current().unwrap().operation_id(),
        Some(task.operation_id())
    );
    tracker.close();
    tracker.drain().await;
}
