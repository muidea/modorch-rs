//! Owner-bound supervised tasks and bounded timer dispatch.
#![forbid(unsafe_code)]
use futures_util::FutureExt;
use modorch_core::*;
use std::{
    collections::BTreeMap,
    future::Future,
    pin::Pin,
    sync::{Arc, Mutex, Weak},
    time::Duration,
};
use tokio::sync::{Semaphore, watch};
pub use tokio_util::sync::CancellationToken;
use tracing::Instrument;

pub type TaskFuture = Pin<Box<dyn Future<Output = FrameworkResult<()>> + Send>>;
pub type TaskFactory = Arc<dyn Fn(CancellationToken) -> TaskFuture + Send + Sync>;
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TaskState {
    Accepted,
    Running,
    Completed,
    Failed,
    CancelRequested,
    Cancelled,
}
impl TaskState {
    fn terminal(self) -> bool {
        matches!(self, Self::Completed | Self::Failed | Self::Cancelled)
    }
}
#[derive(Clone)]
pub struct TaskHandle {
    id: OperationId,
    cancel: CancellationToken,
    state: watch::Sender<TaskState>,
    result: watch::Receiver<Option<FrameworkResult<()>>>,
}
fn request_cancel(cancel: &CancellationToken, state: &watch::Sender<TaskState>) {
    cancel.cancel();
    state.send_if_modified(|s| {
        if !s.terminal() {
            *s = TaskState::CancelRequested;
            true
        } else {
            false
        }
    });
}
impl TaskHandle {
    pub fn operation_id(&self) -> OperationId {
        self.id
    }
    pub fn state(&self) -> TaskState {
        *self.state.borrow()
    }
    /// Cooperative only: the operation remains counted until the future returns.
    pub fn cancel(&self) {
        request_cancel(&self.cancel, &self.state);
    }
    pub async fn wait(&self) -> FrameworkResult<()> {
        let mut result = self.result.clone();
        loop {
            if let Some(result) = result.borrow().clone() {
                return result;
            }
            result.changed().await.map_err(|_| FrameworkError::Closed)?;
        }
    }
}
#[derive(Clone, Copy, Debug)]
pub enum TickPolicy {
    SkipIfRunning,
    QueueBounded { capacity: usize },
    AllowOverlap { max_in_flight: usize },
}
#[derive(Clone, Copy, Debug)]
pub struct IntervalSpec {
    pub period: Duration,
    pub policy: TickPolicy,
}
struct TaskControl {
    cancel: CancellationToken,
    state: watch::Sender<TaskState>,
    abort: tokio::task::AbortHandle,
    owner: ComponentRef,
}
struct TimerControl {
    owner: ComponentRef,
    cancel: CancellationToken,
    abort: tokio::task::AbortHandle,
}
struct Inner {
    tracker: OperationTracker,
    failures: FailureReporter,
    tasks: Mutex<BTreeMap<OperationId, TaskControl>>,
    timers: Mutex<Vec<TimerControl>>,
    task_slots: Arc<Semaphore>,
    timer_slots: Arc<Semaphore>,
}
#[derive(Clone)]
pub struct SchedulerRuntime(Arc<Inner>);
#[derive(Clone)]
pub struct TaskScheduler {
    runtime: SchedulerRuntime,
    owner: ComponentRef,
    generation: u64,
}
pub type TaskGroup = TaskScheduler;
struct TaskGuard {
    runtime: Weak<Inner>,
    id: OperationId,
    state: watch::Sender<TaskState>,
    result: watch::Sender<Option<FrameworkResult<()>>>,
}
impl Drop for TaskGuard {
    fn drop(&mut self) {
        if !self.state.borrow().terminal() {
            self.state.send_replace(TaskState::Cancelled);
            self.result
                .send_replace(Some(Err(FrameworkError::Cancelled)));
        }
        if let Some(runtime) = self.runtime.upgrade() {
            runtime.tasks.lock().unwrap().remove(&self.id);
        }
    }
}
#[derive(Clone)]
pub struct TimerHandle {
    cancel: CancellationToken,
    done: watch::Receiver<bool>,
}
impl TimerHandle {
    pub fn cancel(&self) {
        self.cancel.cancel();
    }
    /// Acknowledges driver exit. Already dispatched tasks have separate handles/accounting.
    pub async fn wait(&self) {
        let mut done = self.done.clone();
        while !*done.borrow() {
            if done.changed().await.is_err() {
                break;
            }
        }
    }
}
struct TimerGuard(watch::Sender<bool>);
impl Drop for TimerGuard {
    fn drop(&mut self) {
        self.0.send_replace(true);
    }
}
impl SchedulerRuntime {
    pub fn new(
        tracker: OperationTracker,
        failures: FailureReporter,
        max_tasks: usize,
        max_timers: usize,
    ) -> FrameworkResult<Self> {
        if max_tasks == 0
            || max_timers == 0
            || max_tasks > Semaphore::MAX_PERMITS
            || max_timers > Semaphore::MAX_PERMITS
        {
            return Err(FrameworkError::InvalidConfig(
                "invalid task/timer limits".into(),
            ));
        }
        Ok(Self(Arc::new(Inner {
            tracker,
            failures,
            tasks: Mutex::new(BTreeMap::new()),
            timers: Mutex::new(vec![]),
            task_slots: Arc::new(Semaphore::new(max_tasks)),
            timer_slots: Arc::new(Semaphore::new(max_timers)),
        })))
    }
    pub fn for_owner(&self, owner: ComponentRef) -> TaskScheduler {
        TaskScheduler {
            runtime: self.clone(),
            generation: self.0.tracker.generation(&owner),
            owner,
        }
    }
    pub fn begin_shutdown(&self) {
        for timer in self.0.timers.lock().unwrap().iter() {
            timer.cancel.cancel();
        }
        for task in self.0.tasks.lock().unwrap().values() {
            request_cancel(&task.cancel, &task.state);
        }
    }
    pub fn pending_owners(&self) -> BTreeMap<ComponentRef, usize> {
        let mut result = BTreeMap::new();
        for task in self.0.tasks.lock().unwrap().values() {
            *result.entry(task.owner.clone()).or_default() += 1;
        }
        result
    }
    pub fn force_cancel(&self) {
        self.begin_shutdown();
        for timer in self.0.timers.lock().unwrap().iter() {
            timer.abort.abort();
        }
        for task in self.0.tasks.lock().unwrap().values() {
            task.abort.abort();
        }
    }
}
impl TaskScheduler {
    pub fn owner(&self) -> &ComponentRef {
        &self.owner
    }
    pub fn spawn<F, Fut>(&self, task: F) -> FrameworkResult<TaskHandle>
    where
        F: FnOnce(CancellationToken) -> Fut + Send + 'static,
        Fut: Future<Output = FrameworkResult<()>> + Send + 'static,
    {
        tokio::runtime::Handle::try_current().map_err(|_| {
            FrameworkError::InvalidConfig("TaskScheduler requires a host Tokio runtime".into())
        })?;
        let rt = &self.runtime.0;
        let slot = rt
            .task_slots
            .clone()
            .try_acquire_owned()
            .map_err(|_| FrameworkError::Backpressure(self.owner.clone()))?;
        let lease = rt
            .tracker
            .admit_bound(self.owner.clone(), self.generation)?;
        let id = lease.id();
        let cancel = CancellationToken::new();
        let (state_tx, _) = watch::channel(TaskState::Accepted);
        let (result_tx, result) = watch::channel(None);
        let guard = TaskGuard {
            runtime: Arc::downgrade(rt),
            id,
            state: state_tx.clone(),
            result: result_tx.clone(),
        };
        let runtime = self.runtime.clone();
        let owner = self.owner.clone();
        let generation = self.generation;
        let task_cancel = cancel.clone();
        let state = state_tx.clone();
        // Registration and completion removal are serialized, including fast futures.
        let mut controls = rt.tasks.lock().unwrap();
        let parent = rt.tracker.current().map(|lease| lease.id());
        let span = if parent.is_some() {
            tracing::info_span!("task", application_id=rt.tracker.application_id(), operation_id=id, component=%owner, causation_id=?parent)
        } else {
            tracing::info_span!(parent: None, "task", application_id=rt.tracker.application_id(), operation_id=id, component=%owner)
        };
        let join = tokio::spawn(
            async move {
                let _guard = guard;
                let _slot = slot;
                state_tx.send_if_modified(|s| {
                    if *s == TaskState::Accepted {
                        *s = TaskState::Running;
                        true
                    } else {
                        false
                    }
                });
                let future =
                    std::panic::AssertUnwindSafe(async { task(task_cancel.clone()).await })
                        .catch_unwind();
                let outcome = runtime.0.tracker.scope(lease.clone(), future).await;
                let result = match outcome {
                    Ok(result) => result.map_err(|error| {
                        if matches!(error, FrameworkError::Cancelled) {
                            error
                        } else {
                            error.in_execution(owner.clone(), Some(id), Phase::Task)
                        }
                    }),
                    Err(_) => Err(FrameworkError::ExecutionFailed {
                        component: owner.clone(),
                        operation_id: Some(id),
                        phase: Phase::Task,
                        detail: "background task panicked".into(),
                        source: None,
                    }),
                };
                let final_state = match &result {
                    Ok(()) => TaskState::Completed,
                    Err(FrameworkError::Cancelled) => TaskState::Cancelled,
                    Err(_) => TaskState::Failed,
                };
                if let Err(error) = &result {
                    if !matches!(error, FrameworkError::Cancelled) {
                        runtime
                            .0
                            .failures
                            .report_for(owner.clone(), generation, error.clone());
                    }
                }
                state_tx.send_replace(final_state);
                result_tx.send_replace(Some(result));
            }
            .instrument(span),
        );
        controls.insert(
            id,
            TaskControl {
                cancel: cancel.clone(),
                state: state.clone(),
                abort: join.abort_handle(),
                owner: self.owner.clone(),
            },
        );
        // A task admitted immediately before shutdown must observe cancellation too.
        if rt.tracker.is_closed() {
            request_cancel(&cancel, &state);
        }
        Ok(TaskHandle {
            id,
            cancel,
            state,
            result,
        })
    }
    pub fn delay(&self, delay: Duration, task: TaskFactory) -> FrameworkResult<TimerHandle> {
        self.timer(delay, None, TickPolicy::SkipIfRunning, task)
    }
    pub fn interval(&self, spec: IntervalSpec, task: TaskFactory) -> FrameworkResult<TimerHandle> {
        if spec.period.is_zero() {
            return Err(FrameworkError::InvalidConfig("zero timer period".into()));
        }
        self.timer(spec.period, Some(spec.period), spec.policy, task)
    }
    fn timer(
        &self,
        delay: Duration,
        period: Option<Duration>,
        policy: TickPolicy,
        task: TaskFactory,
    ) -> FrameworkResult<TimerHandle> {
        tokio::runtime::Handle::try_current().map_err(|_| {
            FrameworkError::InvalidConfig("timers require a host Tokio runtime".into())
        })?;
        let start = tokio::time::Instant::now()
            .checked_add(delay)
            .ok_or_else(|| FrameworkError::InvalidConfig("timer delay overflow".into()))?;
        let overlap = match policy {
            TickPolicy::AllowOverlap { max_in_flight }
                if max_in_flight > 0 && max_in_flight <= Semaphore::MAX_PERMITS =>
            {
                max_in_flight
            }
            TickPolicy::AllowOverlap { .. } => {
                return Err(FrameworkError::InvalidConfig(
                    "invalid timer concurrency".into(),
                ));
            }
            TickPolicy::QueueBounded { capacity: 0 } => {
                return Err(FrameworkError::InvalidConfig(
                    "zero timer queue capacity".into(),
                ));
            }
            _ => 1,
        };
        let rt = &self.runtime.0;
        let mut timers = rt.timers.lock().unwrap();
        if rt.tracker.is_closed() {
            return Err(FrameworkError::Closed);
        }
        let slot = rt
            .timer_slots
            .clone()
            .try_acquire_owned()
            .map_err(|_| FrameworkError::Backpressure(self.owner.clone()))?;
        let lease = rt
            .tracker
            .admit_bound(self.owner.clone(), self.generation)?;
        let cancel = CancellationToken::new();
        let stop = cancel.clone();
        let scheduler = self.clone();
        let (done_tx, done) = watch::channel(false);
        let guard = TimerGuard(done_tx);
        let parent = rt.tracker.current().map(|lease| lease.id());
        let span = if parent.is_some() {
            tracing::info_span!("timer", application_id=rt.tracker.application_id(), operation_id=lease.id(), component=%self.owner, causation_id=?parent)
        } else {
            tracing::info_span!(parent: None, "timer", application_id=rt.tracker.application_id(), operation_id=lease.id(), component=%self.owner)
        };
        timers.retain(|timer| !timer.abort.is_finished());
        let join = tokio::spawn(async move {
            let _guard = guard;
            let _slot = slot;
            let tracker = scheduler.runtime.0.tracker.clone();
            tracker.scope(lease, async {
                let mut ticks = tokio::time::interval_at(start, period.unwrap_or(Duration::from_secs(1)));
                ticks.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
                let mut running: Vec<TaskHandle> = vec![]; let mut pending = 0usize;
                loop {
                    let first = running.first().cloned();
                    let tick = tokio::select! {
                        biased;
                        _ = stop.cancelled() => break,
                        _ = async { if let Some(handle) = first { let _ = handle.wait().await; } else { std::future::pending::<()>().await; } } => false,
                        _ = ticks.tick() => true,
                    };
                    if scheduler.runtime.0.tracker.is_closed() { break; }
                    running.retain(|h| !h.state().terminal());
                    if tick {
                        if running.len() < overlap { pending = pending.saturating_add(1); }
                        else if let TickPolicy::QueueBounded { capacity } = policy { pending = pending.saturating_add(1).min(capacity); }
                    }
                    while pending > 0 && running.len() < overlap {
                        let factory = task.clone(); pending -= 1;
                        match scheduler.spawn(move |cancel| factory(cancel)) {
                            Ok(handle) => running.push(handle),
                            Err(FrameworkError::Backpressure(_)) => break,
                            Err(_) => return,
                        }
                    }
                    if period.is_none() && tick { break; }
                }
            }).await;
        }.instrument(span));
        timers.push(TimerControl {
            owner: self.owner.clone(),
            cancel: cancel.clone(),
            abort: join.abort_handle(),
        });
        if rt.tracker.is_closed() {
            cancel.cancel();
        }
        Ok(TimerHandle { cancel, done })
    }
}

#[derive(Clone, Debug)]
pub struct TaskMetrics {
    pub application_id: ApplicationId,
    pub tasks: usize,
    pub timers: usize,
    pub owners: BTreeMap<ComponentRef, usize>,
}
impl SchedulerRuntime {
    pub fn metrics(&self) -> TaskMetrics {
        let owners = self.pending_owners();
        TaskMetrics {
            application_id: self.0.tracker.application_id(),
            tasks: owners.values().sum(),
            timers: self
                .0
                .timers
                .lock()
                .unwrap()
                .iter()
                .filter(|timer| !timer.abort.is_finished())
                .count(),
            owners,
        }
    }
}

impl SchedulerRuntime {
    pub fn stop_owners(&self, owners: &std::collections::BTreeSet<ComponentRef>) {
        for timer in self.0.timers.lock().unwrap().iter() {
            if owners.contains(&timer.owner) {
                timer.cancel.cancel();
            }
        }
        for task in self.0.tasks.lock().unwrap().values() {
            if owners.contains(&task.owner) {
                request_cancel(&task.cancel, &task.state);
            }
        }
    }
}
