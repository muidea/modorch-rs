use crate::{waitgraph::WaitEdge, *};
use std::{
    marker::PhantomData,
    sync::{Arc, Mutex},
    time::Duration,
};
use tokio::sync::Notify;

pub(crate) struct RequestRecord {
    pub status: RequestStatus,
    pub timed_out: bool,
    wait_ended: bool,
    pub result: Option<FrameworkResult<HandlerReply>>,
}
pub(crate) struct RequestShared {
    pub record: Mutex<RequestRecord>,
    changed: Notify,
    metrics: crate::metrics::MetricSet,
}
impl RequestShared {
    pub fn new(metrics: crate::metrics::MetricSet) -> Arc<Self> {
        Arc::new(Self {
            record: Mutex::new(RequestRecord {
                status: RequestStatus::Queued,
                timed_out: false,
                wait_ended: false,
                result: None,
            }),
            changed: Notify::new(),
            metrics,
        })
    }
    pub fn begin(&self) -> bool {
        let mut r = self.record.lock().unwrap();
        if r.status != RequestStatus::Queued {
            return false;
        }
        r.status = RequestStatus::Running;
        true
    }
    pub fn complete(&self, result: FrameworkResult<HandlerReply>) {
        let mut r = self.record.lock().unwrap();
        r.status = if matches!(&result, Err(FrameworkError::CanceledBeforeStart(_))) {
            if r.status == RequestStatus::Queued {
                self.metrics.canceled();
            }
            RequestStatus::CanceledBeforeStart
        } else if r.timed_out {
            RequestStatus::CompletedAfterCallerTimeout
        } else {
            RequestStatus::Completed
        };
        r.result = Some(result);
        self.changed.notify_waiters();
    }
    pub(crate) fn cancel_wait(&self, id: OperationId, timeout: bool) -> FrameworkError {
        let mut r = self.record.lock().unwrap();
        if !r.wait_ended {
            if timeout {
                self.metrics.timed_out();
            } else {
                self.metrics.caller_canceled();
            }
            r.wait_ended = true;
        }
        r.timed_out |= timeout;
        match r.status {
            RequestStatus::Queued | RequestStatus::CanceledBeforeStart => {
                if r.status == RequestStatus::Queued {
                    self.metrics.canceled();
                }
                r.status = RequestStatus::CanceledBeforeStart;
                self.changed.notify_waiters();
                FrameworkError::CanceledBeforeStart(id)
            }
            _ => FrameworkError::Indeterminate(id),
        }
    }
}
pub struct RequestHandle<R> {
    pub(crate) target: ComponentRef,
    pub(crate) id: OperationId,
    pub(crate) shared: Arc<RequestShared>,
    pub(crate) edge: Option<WaitEdge>,
    pub(crate) marker: PhantomData<R>,
}
impl<R: Send + Sync + 'static> RequestHandle<R> {
    pub fn operation_id(&self) -> OperationId {
        self.id
    }
    pub fn status(&self) -> RequestStatus {
        self.shared.record.lock().unwrap().status
    }
    pub fn observation(&self) -> RequestObservation {
        RequestObservation {
            shared: self.shared.clone(),
        }
    }
    pub async fn wait(mut self, timeout: Duration) -> FrameworkResult<Arc<R>> {
        let wait = async {
            loop {
                let notified = self.shared.changed.notified();
                tokio::pin!(notified);
                notified.as_mut().enable();
                {
                    let r = self.shared.record.lock().unwrap();
                    if let Some(result) = &r.result {
                        return result.clone();
                    }
                    if r.status == RequestStatus::CanceledBeforeStart {
                        return Err(FrameworkError::CanceledBeforeStart(self.id));
                    }
                }
                notified.await;
            }
        };
        let reply = match tokio::time::timeout(timeout, wait).await {
            Ok(result) => result,
            Err(_) => {
                let result = self.shared.record.lock().unwrap().result.clone();
                result.unwrap_or_else(|| Err(self.shared.cancel_wait(self.id, true)))
            }
        };
        self.edge.take();
        reply?.downcast::<R>().map_err(|_| {
            FrameworkError::TypeMismatch("request reply".into()).in_execution(
                self.target.clone(),
                Some(self.id),
                Phase::Handle,
            )
        })
    }
    pub fn cancel(self) -> FrameworkError {
        self.shared.cancel_wait(self.id, false)
    }
}
impl<R> Drop for RequestHandle<R> {
    fn drop(&mut self) {
        let status = self.shared.record.lock().unwrap().status;
        if matches!(status, RequestStatus::Queued | RequestStatus::Running) {
            self.shared.cancel_wait(self.id, false);
        }
    }
}
#[derive(Clone)]
pub struct RequestObservation {
    shared: Arc<RequestShared>,
}
impl RequestObservation {
    pub fn status(&self) -> RequestStatus {
        self.shared.record.lock().unwrap().status
    }
}

pub(crate) struct RequestGuard {
    pub shared: Arc<RequestShared>,
    pub id: OperationId,
    pub armed: bool,
}
impl std::ops::Deref for RequestGuard {
    type Target = RequestShared;
    fn deref(&self) -> &RequestShared {
        &self.shared
    }
}
impl Drop for RequestGuard {
    fn drop(&mut self) {
        if !self.armed {
            return;
        }
        let status = self.shared.record.lock().unwrap().status;
        match status {
            RequestStatus::Running => self
                .shared
                .complete(Err(FrameworkError::Indeterminate(self.id))),
            RequestStatus::Queued => self
                .shared
                .complete(Err(FrameworkError::CanceledBeforeStart(self.id))),
            _ => {}
        }
    }
}
