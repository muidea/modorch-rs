//! In-process typed messages, bounded mailboxes and acknowledged routing changes.
#![forbid(unsafe_code)]
mod admission;
mod metrics;
mod request;
pub use metrics::{
    ExecutionMetrics, MESSAGE_METRIC_LABEL_LIMIT, MessageMetricLabels, MessageMetrics, RouteOutcome,
};
mod types;
mod waitgraph;
mod workers;
use modorch_core::*;
use request::{RequestGuard, RequestShared};
pub use request::{RequestHandle, RequestObservation};
use std::{
    collections::{BTreeMap, BTreeSet},
    sync::{
        Arc, Mutex,
        atomic::{AtomicU64, Ordering},
    },
};
use tokio::sync::mpsc;
pub use types::*;
use waitgraph::{EXECUTION, Node, WaitGraph};
pub use workers::*;

struct Dispatch {
    envelope: MessageEnvelope,
    lease: OperationLease,
    request: Option<RequestGuard>,
    span: tracing::Span,
    metrics: metrics::MetricSet,
}
struct Lane {
    sender: mpsc::Sender<Dispatch>,
    node: usize,
}
struct DynamicEndpoint {
    lanes: BTreeMap<String, Lane>,
    factory: Arc<dyn HandlerFactory>,
    max_lanes: usize,
    idle_timeout: std::time::Duration,
    capacity: usize,
    next: usize,
}
struct Endpoint {
    senders: Vec<mpsc::Sender<Dispatch>>,
    dynamic: Option<DynamicEndpoint>,
}
impl Endpoint {
    fn senders(&self) -> Vec<&mpsc::Sender<Dispatch>> {
        if let Some(dynamic) = &self.dynamic {
            dynamic.lanes.values().map(|lane| &lane.sender).collect()
        } else {
            self.senders.iter().collect()
        }
    }
}
struct Routing {
    endpoints: BTreeMap<ComponentRef, Endpoint>,
    subscriptions: BTreeMap<SubscriptionId, SubscriptionSpec>,
    generation: u64,
    terminated: bool,
}
struct Inner {
    routing: Mutex<Routing>,
    tracker: OperationTracker,
    failures: FailureReporter,
    graph: WaitGraph,
    workers: Mutex<BTreeMap<ComponentRef, Vec<tokio::task::JoinHandle<()>>>>,
    capacity_changed: tokio::sync::Notify,
    accepted: AtomicU64,
    rejected: AtomicU64,
    metrics: Arc<metrics::Metrics>,
    message_metrics: metrics::MessageMetricsRegistry,
}
#[derive(Clone)]
pub struct EventHub(Arc<Inner>);
#[derive(Clone, Copy, Debug)]
pub struct HubMetrics {
    pub application_id: ApplicationId,
    pub accepted: u64,
    pub rejected: u64,
    pub queued: usize,
    pub execution: ExecutionMetrics,
}
impl EventHub {
    pub fn new(tracker: OperationTracker, failures: FailureReporter) -> Self {
        Self(Arc::new(Inner {
            routing: Mutex::new(Routing {
                endpoints: BTreeMap::new(),
                subscriptions: BTreeMap::new(),
                generation: 0,
                terminated: false,
            }),
            tracker,
            failures,
            graph: WaitGraph::default(),
            workers: Mutex::new(BTreeMap::new()),
            capacity_changed: tokio::sync::Notify::new(),
            accepted: AtomicU64::new(0),
            rejected: AtomicU64::new(0),
            metrics: Arc::default(),
            message_metrics: Default::default(),
        }))
    }
    pub fn subscribe(&self, spec: SubscriptionSpec) -> FrameworkResult<SubscriptionReceipt> {
        validate_pattern(&spec.topic_pattern)?;
        let mut r = self.0.routing.lock().unwrap();
        if r.terminated || self.0.tracker.is_closed() {
            return Err(FrameworkError::Closed);
        }
        if !r.endpoints.contains_key(&spec.target) {
            return Err(FrameworkError::ComponentUnavailable(spec.target));
        }
        if r.subscriptions.contains_key(&spec.id) {
            return Err(FrameworkError::InvalidConfig(format!(
                "duplicate subscription {}",
                spec.id
            )));
        }
        let id = spec.id;
        r.subscriptions.insert(id, spec);
        r.generation += 1;
        Ok(SubscriptionReceipt {
            id,
            generation: r.generation,
        })
    }
    pub fn unsubscribe(&self, id: SubscriptionId) -> FrameworkResult<SubscriptionReceipt> {
        let mut r = self.0.routing.lock().unwrap();
        if r.terminated {
            return Err(FrameworkError::Closed);
        }
        if r.subscriptions.remove(&id).is_none() {
            return Err(FrameworkError::InvalidConfig(format!(
                "unknown subscription {id}"
            )));
        }
        r.generation += 1;
        Ok(SubscriptionReceipt {
            id,
            generation: r.generation,
        })
    }
    fn targets(r: &Routing, topic: &str, destination: &Destination) -> Vec<ComponentRef> {
        r.subscriptions
            .values()
            .filter(|s| {
                topic_matches(&s.topic_pattern, topic)
                    && match destination {
                        Destination::Component(c) => c == &s.target,
                        _ => true,
                    }
                    && match &s.destination_pattern {
                        DestinationPattern::Any => true,
                        DestinationPattern::Exact(d) => d == destination,
                    }
            })
            .map(|s| s.target.clone())
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect()
    }
    fn shard(endpoint: &Endpoint, lane: &Option<String>) -> usize {
        // Fixed FNV-1a rather than randomized hashing; Lane never influences routing.
        let hash = lane
            .as_deref()
            .unwrap_or("")
            .bytes()
            .fold(0xcbf29ce484222325u64, |h, b| {
                (h ^ b as u64).wrapping_mul(0x100000001b3)
            });
        (hash % endpoint.senders.len() as u64) as usize
    }
    #[allow(clippy::too_many_arguments)]
    fn send(
        &self,
        r: &mut Routing,
        target: &ComponentRef,
        kind: MessageKind,
        topic: &str,
        destination: &Destination,
        payload: MessagePayload,
        options: MessageOptions,
        request: Option<Arc<RequestShared>>,
    ) -> FrameworkResult<AdmissionReceipt> {
        let result = self.send_inner(
            r,
            target,
            kind,
            topic,
            destination,
            payload,
            options,
            request,
        );
        self.record_route(Some(target), kind, topic, &result);
        result
    }
    #[allow(clippy::too_many_arguments)]
    fn send_inner(
        &self,
        r: &mut Routing,
        target: &ComponentRef,
        kind: MessageKind,
        topic: &str,
        destination: &Destination,
        payload: MessagePayload,
        options: MessageOptions,
        request: Option<Arc<RequestShared>>,
    ) -> FrameworkResult<AdmissionReceipt> {
        if r.terminated {
            return Err(FrameworkError::Closed);
        }
        if options
            .deadline
            .is_some_and(|d| d <= std::time::Instant::now())
        {
            return Err(FrameworkError::AdmissionTimeout);
        }
        let lease = self.0.tracker.admit(target.clone())?;
        let (sender, _) = self.sender(r, target, &options.lane_key)?;
        let id = lease.id();
        let source = self
            .0
            .tracker
            .current()
            .and_then(|_| EXECUTION.try_with(|n| n.0.clone()).ok());
        let causation = self.0.tracker.current().map(|p| p.id());
        let envelope = MessageEnvelope {
            message_id: id,
            kind,
            topic: topic.into(),
            source,
            destination: destination.clone(),
            lane_key: options.lane_key,
            correlation_id: if kind == MessageKind::Request {
                Some(id)
            } else {
                None
            },
            causation_id: causation,
            deadline: options.deadline,
            headers: options.headers,
            payload,
        };
        sender.try_send(Dispatch {
                envelope,
                lease,
                request: request.map(|shared| RequestGuard { shared, id, armed: true }),
                span: if causation.is_some() {
                    tracing::info_span!("message", application_id=self.0.tracker.application_id(), operation_id=id, topic, target=%target, kind=?kind, causation_id=?causation)
                } else {
                    tracing::info_span!(parent: None, "message", application_id=self.0.tracker.application_id(), operation_id=id, topic, target=%target, kind=?kind)
                },
                metrics: self.execution_metrics(target, kind, topic),
            })
            .map_err(|error| {
                let result = match &error {
                    mpsc::error::TrySendError::Full(_) => FrameworkError::Backpressure(target.clone()),
                    mpsc::error::TrySendError::Closed(_) => FrameworkError::Closed,
                };
                // A rejected dispatch was never accepted: dropping its receipt must
                // not count as cancellation of an admitted request.
                let mut dispatch = error.into_inner();
                if let Some(request) = &mut dispatch.request { request.armed = false; }
                result
            })?;
        Ok(AdmissionReceipt {
            operation_id: id,
            target: target.clone(),
        })
    }
    pub fn publish<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        event: T,
        options: MessageOptions,
        _policy: PublishPolicy,
    ) -> FrameworkResult<PublishReport> {
        let mut r = self.0.routing.lock().unwrap();
        if r.terminated || (self.0.tracker.is_closed() && self.0.tracker.current().is_none()) {
            let result = Err(FrameworkError::Closed);
            self.record_route::<()>(None, MessageKind::Event, topic, &result);
            return Err(FrameworkError::Closed);
        }
        let targets = Self::targets(&r, topic, &destination);
        if targets.is_empty() {
            let result = Err(FrameworkError::Unroutable(topic.into()));
            self.record_route::<()>(None, MessageKind::Event, topic, &result);
            return Err(FrameworkError::Unroutable(topic.into()));
        }
        let payload: MessagePayload = Arc::new(event);
        Ok(PublishReport {
            deliveries: targets
                .into_iter()
                .map(|target| {
                    let result = self.send(
                        &mut r,
                        &target,
                        MessageKind::Event,
                        topic,
                        &destination,
                        payload.clone(),
                        options.clone(),
                        None,
                    );
                    Delivery { target, result }
                })
                .collect(),
        })
    }
    pub fn command<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        command: T,
        options: MessageOptions,
    ) -> FrameworkResult<AdmissionReceipt> {
        let mut r = self.0.routing.lock().unwrap();
        let target = self.unique_target(&r, MessageKind::Command, topic, &destination)?;
        self.send(
            &mut r,
            &target,
            MessageKind::Command,
            topic,
            &destination,
            Arc::new(command),
            options,
            None,
        )
    }
    pub fn request<T: Send + Sync + 'static, R: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        request: T,
        options: MessageOptions,
    ) -> FrameworkResult<RequestHandle<R>> {
        let mut r = self.0.routing.lock().unwrap();
        let target = self.unique_target(&r, MessageKind::Request, topic, &destination)?;
        let (_, shard) = self
            .sender(&mut r, &target, &options.lane_key)
            .inspect_err(|error| {
                self.record_route::<()>(
                    Some(&target),
                    MessageKind::Request,
                    topic,
                    &Err(error.clone()),
                );
            })?;
        let edge = if let Some(from) = self
            .0
            .tracker
            .current()
            .and_then(|_| EXECUTION.try_with(Clone::clone).ok())
        {
            Some(
                self.0
                    .graph
                    .insert(from, Node(target.clone(), shard))
                    .inspect_err(|error| {
                        self.record_route::<()>(
                            Some(&target),
                            MessageKind::Request,
                            topic,
                            &Err(error.clone()),
                        );
                    })?,
            )
        } else {
            None
        };
        let shared =
            RequestShared::new(self.execution_metrics(&target, MessageKind::Request, topic));
        let receipt = self.send(
            &mut r,
            &target,
            MessageKind::Request,
            topic,
            &destination,
            Arc::new(request),
            options,
            Some(shared.clone()),
        )?;
        Ok(RequestHandle {
            target: target.clone(),
            id: receipt.operation_id,
            shared,
            edge,
            marker: std::marker::PhantomData,
        })
    }
    fn unique_target(
        &self,
        r: &Routing,
        kind: MessageKind,
        topic: &str,
        destination: &Destination,
    ) -> FrameworkResult<ComponentRef> {
        let result = if r.terminated {
            Err(FrameworkError::Closed)
        } else {
            let targets = Self::targets(r, topic, destination);
            match targets.len() {
                0 => Err(FrameworkError::Unroutable(topic.into())),
                1 => Ok(targets[0].clone()),
                _ => Err(FrameworkError::AmbiguousDestination(topic.into())),
            }
        };
        if result.is_err() {
            self.record_route(None, kind, topic, &result);
        }
        result
    }
    fn execution_metrics(
        &self,
        target: &ComponentRef,
        kind: MessageKind,
        topic: &str,
    ) -> metrics::MetricSet {
        metrics::MetricSet([
            self.0.metrics.clone(),
            self.0
                .message_metrics
                .get(Some(target), kind, topic)
                .execution
                .clone(),
        ])
    }
    fn record_route<T>(
        &self,
        target: Option<&ComponentRef>,
        kind: MessageKind,
        topic: &str,
        result: &FrameworkResult<T>,
    ) {
        self.0
            .message_metrics
            .get(target, kind, topic)
            .record(RouteOutcome::from_result(result));
        if result.is_ok() {
            self.0.accepted.fetch_add(1, Ordering::Relaxed);
        } else {
            self.0.rejected.fetch_add(1, Ordering::Relaxed);
        }
    }
    /// Bounded label sets; snapshots are independently sampled, not transactional.
    pub fn message_metrics(&self) -> Vec<MessageMetrics> {
        self.0
            .message_metrics
            .snapshot(self.0.tracker.application_id())
    }
    pub fn metrics(&self) -> HubMetrics {
        let r = self.0.routing.lock().unwrap();
        HubMetrics {
            application_id: self.0.tracker.application_id(),
            accepted: self.0.accepted.load(Ordering::Relaxed),
            execution: self.0.metrics.snapshot(),
            rejected: self.0.rejected.load(Ordering::Relaxed),
            queued: r
                .endpoints
                .values()
                .flat_map(Endpoint::senders)
                .map(|s| s.max_capacity() - s.capacity())
                .sum(),
        }
    }
    /// Must be called after the shared tracker reaches zero. Force only aborts executors.
    pub async fn terminate(&self, force: bool) {
        {
            let mut r = self.0.routing.lock().unwrap();
            r.terminated = true;
            r.subscriptions.clear();
            r.endpoints.clear();
            self.0.capacity_changed.notify_waiters();
        }
        let workers = std::mem::take(&mut *self.0.workers.lock().unwrap());
        for worker in workers.into_values().flatten() {
            if force {
                worker.abort();
            }
            let _ = worker.await;
        }
    }
}

/// Adapter for external ingress running inside framework-owned producer tasks.
/// Every submission establishes a new root, so shutdown cannot be bypassed by
/// inheriting the producer task's pre-existing operation.
#[derive(Clone)]
pub struct ExternalEventHub(EventHub);
impl EventHub {
    pub fn external(&self) -> ExternalEventHub {
        ExternalEventHub(self.clone())
    }
}
impl ExternalEventHub {
    pub fn command<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        command: T,
        options: MessageOptions,
    ) -> FrameworkResult<AdmissionReceipt> {
        self.0
            .0
            .tracker
            .as_root(|| self.0.command(topic, destination, command, options))
    }
    pub fn request<T: Send + Sync + 'static, R: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        request: T,
        options: MessageOptions,
    ) -> FrameworkResult<RequestHandle<R>> {
        self.0
            .0
            .tracker
            .as_root(|| self.0.request(topic, destination, request, options))
    }
    pub fn publish<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        event: T,
        options: MessageOptions,
        policy: PublishPolicy,
    ) -> FrameworkResult<PublishReport> {
        self.0
            .0
            .tracker
            .as_root(|| self.0.publish(topic, destination, event, options, policy))
    }
}

#[derive(Clone, Debug)]
pub struct MailboxMetrics {
    pub target: ComponentRef,
    pub application_id: ApplicationId,
    pub active_lanes: usize,
    pub shard_capacity: usize,
    pub shard_queue_depths: Vec<usize>,
}
impl EventHub {
    pub fn mailbox_metrics(&self) -> Vec<MailboxMetrics> {
        let routing = self.0.routing.lock().unwrap();
        routing
            .endpoints
            .iter()
            .map(|(target, endpoint)| MailboxMetrics {
                target: target.clone(),
                application_id: self.0.tracker.application_id(),
                active_lanes: endpoint.senders().len(),
                shard_capacity: endpoint
                    .dynamic
                    .as_ref()
                    .map(|d| d.capacity)
                    .unwrap_or_else(|| endpoint.senders[0].max_capacity()),
                shard_queue_depths: endpoint
                    .senders()
                    .iter()
                    .map(|sender| sender.max_capacity() - sender.capacity())
                    .collect(),
            })
            .collect()
    }
    /// Called only after the selected closure's operations and leases have drained.
    pub async fn remove_owners(&self, owners: &BTreeSet<ComponentRef>) {
        {
            let mut routing = self.0.routing.lock().unwrap();
            routing
                .subscriptions
                .retain(|_, spec| !owners.contains(&spec.target));
            routing.endpoints.retain(|owner, _| !owners.contains(owner));
            routing.generation += 1;
            self.0.capacity_changed.notify_waiters();
        }
        let workers = {
            let mut workers = self.0.workers.lock().unwrap();
            owners
                .iter()
                .flat_map(|owner| workers.remove(owner).unwrap_or_default())
                .collect::<Vec<_>>()
        };
        for worker in workers {
            let _ = worker.await;
        }
    }
}
