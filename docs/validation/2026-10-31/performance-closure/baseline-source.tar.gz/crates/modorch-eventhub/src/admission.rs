use crate::*;
use std::time::Duration;

impl EventHub {
    /// Wait for capacity without holding the routing lock or allocating an unbounded
    /// mailbox. Cancellation drops the waiter without a late enqueue.
    async fn await_admission<T>(
        &self,
        timeout: Duration,
        kind: MessageKind,
        topic: &str,
        target: Option<&ComponentRef>,
        mut submit: impl FnMut() -> FrameworkResult<T>,
    ) -> FrameworkResult<T> {
        if self.0.tracker.current().is_some() && EXECUTION.try_with(|_| ()).is_ok() {
            let error = FrameworkError::InvalidConfig(
                "waiting for mailbox capacity from a handler is forbidden; use immediate admission"
                    .into(),
            );
            self.record_route::<()>(target, kind, topic, &Err(error.clone()));
            return Err(error);
        }
        let deadline = tokio::time::Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| FrameworkError::InvalidConfig("admission timeout overflow".into()))?;
        let timed_out = |target: Option<&ComponentRef>| {
            let error = FrameworkError::AdmissionTimeout;
            self.record_route::<()>(target, kind, topic, &Err(error.clone()));
            error
        };
        loop {
            let notified = self.0.capacity_changed.notified();
            tokio::pin!(notified);
            notified.as_mut().enable();
            let last_target = match submit() {
                Ok(value) => return Ok(value),
                Err(FrameworkError::Backpressure(owner)) => owner,
                Err(error) => return Err(error),
            };
            if tokio::time::Instant::now() >= deadline {
                return Err(timed_out(Some(&last_target)));
            }
            // AdmissionGate close is also checked periodically so a waiter cannot
            // remain asleep behind a handler that ignores shutdown indefinitely.
            tokio::select! {_=notified=>{},_=tokio::time::sleep_until(deadline)=>return Err(timed_out(Some(&last_target))),_=tokio::time::sleep(Duration::from_millis(5))=>{}}
        }
    }
    pub async fn command_wait<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        command: T,
        options: MessageOptions,
        timeout: Duration,
    ) -> FrameworkResult<AdmissionReceipt> {
        let payload: MessagePayload = Arc::new(command);
        self.await_admission(timeout, MessageKind::Command, topic, None, || {
            let mut routing = self.0.routing.lock().unwrap();
            let target = self.unique_target(&routing, MessageKind::Command, topic, &destination)?;
            self.send(
                &mut routing,
                &target,
                MessageKind::Command,
                topic,
                &destination,
                payload.clone(),
                options.clone(),
                None,
            )
        })
        .await
    }
    pub async fn request_wait<T: Send + Sync + 'static, R: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        request: T,
        options: MessageOptions,
        timeout: Duration,
    ) -> FrameworkResult<RequestHandle<R>> {
        let payload: MessagePayload = Arc::new(request);
        self.await_admission(timeout, MessageKind::Request, topic, None, || {
            let mut routing = self.0.routing.lock().unwrap();
            let target = self.unique_target(&routing, MessageKind::Request, topic, &destination)?;
            let shared =
                RequestShared::new(self.execution_metrics(&target, MessageKind::Request, topic));
            let receipt = self.send(
                &mut routing,
                &target,
                MessageKind::Request,
                topic,
                &destination,
                payload.clone(),
                options.clone(),
                Some(shared.clone()),
            )?;
            Ok(RequestHandle {
                target: target.clone(),
                id: receipt.operation_id,
                shared,
                edge: None,
                marker: std::marker::PhantomData,
            })
        })
        .await
    }
    /// Acknowledges targets independently. Already admitted fanout legs are never
    /// retried. Timed out targets remain explicit errors in the delivery report.
    pub async fn publish_wait<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        event: T,
        options: MessageOptions,
        timeout: Duration,
    ) -> FrameworkResult<PublishReport> {
        let payload: MessagePayload = Arc::new(event);
        let targets = {
            let routing = self.0.routing.lock().unwrap();
            if routing.terminated {
                self.record_route::<()>(
                    None,
                    MessageKind::Event,
                    topic,
                    &Err(FrameworkError::Closed),
                );
                return Err(FrameworkError::Closed);
            }
            Self::targets(&routing, topic, &destination)
        };
        if targets.is_empty() {
            self.record_route::<()>(
                None,
                MessageKind::Event,
                topic,
                &Err(FrameworkError::Unroutable(topic.into())),
            );
            return Err(FrameworkError::Unroutable(topic.into()));
        }
        let deadline = tokio::time::Instant::now()
            .checked_add(timeout)
            .ok_or_else(|| FrameworkError::InvalidConfig("admission timeout overflow".into()))?;
        let deliveries = futures_util::future::join_all(targets.into_iter().map(|target| {
            let payload = payload.clone();
            let destination = &destination;
            let options = &options;
            async move {
                let result = self
                    .await_admission(
                        deadline.saturating_duration_since(tokio::time::Instant::now()),
                        MessageKind::Event,
                        topic,
                        Some(&target),
                        || {
                            let mut routing = self.0.routing.lock().unwrap();
                            if !Self::targets(&routing, topic, destination).contains(&target) {
                                let error = if routing.terminated {
                                    FrameworkError::Closed
                                } else {
                                    FrameworkError::Unroutable(topic.into())
                                };
                                self.record_route::<()>(
                                    Some(&target),
                                    MessageKind::Event,
                                    topic,
                                    &Err(error.clone()),
                                );
                                return Err(error);
                            }
                            self.send(
                                &mut routing,
                                &target,
                                MessageKind::Event,
                                topic,
                                destination,
                                payload.clone(),
                                options.clone(),
                                None,
                            )
                        },
                    )
                    .await;
                Delivery { target, result }
            }
        }))
        .await;
        Ok(PublishReport { deliveries })
    }
}
impl ExternalEventHub {
    pub async fn command_wait<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        command: T,
        options: MessageOptions,
        timeout: Duration,
    ) -> FrameworkResult<AdmissionReceipt> {
        self.0
            .0
            .tracker
            .scope_root(
                self.0
                    .command_wait(topic, destination, command, options, timeout),
            )
            .await
    }
    pub async fn request_wait<T: Send + Sync + 'static, R: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        request: T,
        options: MessageOptions,
        timeout: Duration,
    ) -> FrameworkResult<RequestHandle<R>> {
        self.0
            .0
            .tracker
            .scope_root(
                self.0
                    .request_wait(topic, destination, request, options, timeout),
            )
            .await
    }
    pub async fn publish_wait<T: Send + Sync + 'static>(
        &self,
        topic: &str,
        destination: Destination,
        event: T,
        options: MessageOptions,
        timeout: Duration,
    ) -> FrameworkResult<PublishReport> {
        self.0
            .0
            .tracker
            .scope_root(
                self.0
                    .publish_wait(topic, destination, event, options, timeout),
            )
            .await
    }
}
